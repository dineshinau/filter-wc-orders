=== Filter WC Orders ===
Contributors: dineshinau
Tags: woocommerce order filter, filter orders, filter wc order, payment gateway, gateway-based filter.
Requires at least: 6.5
Tested up to: 7.1
Stable tag: 1.1.0
Requires PHP: 7.4
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Filter WC Orders adds a new filter dropdown on the admin order screen.

== Description ==

It provides a way to admin for filtering woocommerce orders based on payment gateways and user types.

== Features ==

1. **Payment Gateway Based Filters**
Admin can view all orders processed through a specific payment gateway (Screenshot-1)

2. **User Type Based Filters**
Orders can be filtered also by Guest users and shop customers

= Connect with the developer =

* [Website](https://dineshinaublog.wordpress.com/)
* [Facebook](https://www.facebook.com/dineshinau/)
* [X](https://x.com/dineshinau/)
* [LinkedIn](https://www.linkedin.com/in/dineshinau/)
* [GitHub](https://github.com/dineshinau/)

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/filter-wc-orders` directory, or install the plugin through the WordPress plugins screen directly.

2. Activate the plugin through the \' Plugins\' screen in WordPress

3. Go to the woocommerce orders page on the admin dashboard.

4. Select the option from the new dropdown and apply the filter.

== Frequently Asked Questions ==

= What types of filters are in this plugin? =
Admin and shop-managers can filter orders based on installed Payment Gateways and user types viz. guest and logged in.

== Screenshots ==

1. **Filter Location** - It shows filter on order screen in admin dashboard.
 screenshot-1.png

== Changelog ==
= 1.1.0 (14-10-2026) =
* Added: Feature to filter orders based on payment gateways and user types
* Improved: Payment method filters now fall back to the gateway title when the method title is empty.
* Updated: Plugin metadata and WordPress compatibility requirements.
* Refactored: Core structure and user action logging.
* Updated: Coding structure according to phpcs-4.0

= 1.0.1 (08-05-2022) =
* Updated: Tested upto WordPress 6.0

= 1.0 (24-07-2021) =
This is the Initial Release of the plugin.
